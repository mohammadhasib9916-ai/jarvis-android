package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
            fileUploadCallback?.onReceiveValue(uris)
        } else {
            fileUploadCallback?.onReceiveValue(null)
        }
        fileUploadCallback = null
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Handle runtime permission grants
    }

    companion object {
        var instance: MainActivity? = null
            private set
        const val PREFS_NAME = "jarvis_companion_prefs"
        const val KEY_APP_URL = "custom_jarvis_url"
        const val DEFAULT_CLOUD_URL = "https://jarvis-personal-assistant-6607.ai.studio"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this

        // Request runtime permissions
        requestAppPermissions()

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.setGeolocationEnabled(true)
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.cacheMode = WebSettings.LOAD_DEFAULT

            // Bind native bridge with security check
            addJavascriptInterface(JarvisJsBridge(this@MainActivity), "AndroidCompanion")

            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    callback?.invoke(origin, true, false)
                }

                override fun onPermissionRequest(request: PermissionRequest?) {
                    // Automatically grant audio recording & camera to web app
                    request?.grant(request.resources)
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileUploadCallback?.onReceiveValue(null)
                    fileUploadCallback = filePathCallback

                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    filePickerLauncher.launch(intent)
                    return true
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString() ?: return false
                    if (url.startsWith("tel:") || url.startsWith("sms:") || url.startsWith("mailto:") || url.startsWith("geo:") || url.startsWith("vnd.youtube:")) {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(intent)
                        return true
                    }
                    return false
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    // Only show fallback screen for main frame failures
                    if (request?.isForMainFrame == true) {
                        val failingUrl = request.url?.toString() ?: ""
                        showConnectionFallback(failingUrl)
                    }
                }
            }
        }

        setContentView(webView)

        // Load configured JARVIS URL
        loadJarvisUrl()
    }

    fun getEffectiveAppUrl(): String {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedUrl = prefs.getString(KEY_APP_URL, null)

        // Sanitize legacy or corrupted URLs (e.g. localhost:3000, 127.0.0.1, or old un-published ais-pre url)
        if (savedUrl.isNullOrBlank() ||
            savedUrl.contains("localhost") ||
            savedUrl.contains("127.0.0.1") ||
            savedUrl.contains("ais-pre-ycq4dyrjjh2yp6rxr6jzgp")) {
            // Overwrite old localhost or obsolete URL entry in SharedPreferences
            prefs.edit().putString(KEY_APP_URL, DEFAULT_CLOUD_URL).apply()
            return DEFAULT_CLOUD_URL
        }
        return savedUrl
    }

    fun saveCustomAppUrl(newUrl: String) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val sanitized = if (newUrl.contains("localhost") || newUrl.contains("127.0.0.1")) {
            DEFAULT_CLOUD_URL
        } else {
            newUrl.trim()
        }
        prefs.edit().putString(KEY_APP_URL, sanitized).apply()
        runOnUiThread {
            loadJarvisUrl()
        }
    }

    private fun loadJarvisUrl() {
        val appUrl = getEffectiveAppUrl()
        webView.loadUrl(appUrl)
    }

    private fun showConnectionFallback(failedUrl: String) {
        val isLocalhost = failedUrl.contains("localhost") || failedUrl.contains("127.0.0.1")
        val errorExplanation = if (isLocalhost) {
            "آپ کا سیٹ کردہ URL (localhost:3000) اصلی فون پر کام نہیں کرتا کیونکہ اینڈرائیڈ کے لیے localhost فون کا اپنا ہارڈویئر ہوتا ہے۔ براہ کرم نیچے کلاؤڈ رن کا لائیو HTTPS URL درج کریں۔"
        } else {
            "JARVIS سرور سے رابطہ قائم نہیں ہو سکا۔ انٹرنیٹ کنکشن چیک کریں یا یقینی بنائیں کہ گوگل اے آئی اسٹوڈیو میں ایپ 'Publish' ہو چکی ہے۔"
        }

        val html = """
            <!DOCTYPE html>
            <html lang="ur" dir="rtl">
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>JARVIS Connection Guide</title>
                <style>
                    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #020617; color: #f8fafc; padding: 24px; text-align: center; }
                    .card { background: #0f172a; border: 1px solid #1e293b; border-radius: 20px; padding: 24px; max-width: 480px; margin: 30px auto; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
                    .icon { font-size: 40px; margin-bottom: 12px; }
                    h2 { color: #38bdf8; margin: 0 0 12px 0; font-size: 20px; }
                    p { color: #94a3b8; font-size: 13px; line-height: 1.6; margin: 8px 0; }
                    .input-box { width: 90%; padding: 12px; border-radius: 12px; border: 1px solid #334155; background: #020617; color: #38bdf8; font-family: monospace; font-size: 12px; margin: 16px 0; text-align: left; dir: ltr; }
                    .btn { background: #0284c7; color: white; border: none; padding: 12px 24px; border-radius: 12px; font-weight: bold; font-size: 14px; cursor: pointer; width: 100%; box-sizing: border-box; }
                    .btn:hover { background: #0369a1; }
                    .btn-secondary { background: #1e293b; color: #cbd5e1; margin-top: 10px; }
                    .footer-note { font-size: 11px; color: #64748b; margin-top: 16px; font-family: monospace; text-align: left; }
                </style>
            </head>
            <body>
                <div class="card">
                    <div class="icon">⚡</div>
                    <h2>JARVIS سرور سے رابطہ نہیں ہو سکا</h2>
                    <p>$errorExplanation</p>
                    
                    <input type="text" id="urlInput" class="input-box" value="$DEFAULT_CLOUD_URL" placeholder="https://..." />
                    
                    <button class="btn" onclick="saveAndReload()">محفوظ کریں اور لوڈ کریں (Connect)</button>
                    <button class="btn btn-secondary" onclick="location.reload()">دوبارہ کوشش کریں (Retry)</button>
                    
                    <div class="footer-note">
                        Failed URL: $failedUrl<br/>
                        Notice: Localhost:3000 is for emulator/desktop only. Physical phones require live HTTPS URL.
                    </div>
                </div>
                <script>
                    function saveAndReload() {
                        var val = document.getElementById('urlInput').value.trim();
                        if (val) {
                            if (window.AndroidCompanion && window.AndroidCompanion.saveCustomAppUrl) {
                                window.AndroidCompanion.saveCustomAppUrl(val);
                            } else {
                                window.location.href = val;
                            }
                        }
                    }
                </script>
            </body>
            </html>
        """.trimIndent()

        runOnUiThread {
            webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        }
    }

    fun dispatchNotificationToWeb(app: String, packageName: String, sender: String, text: String) {
        val payload = JSONObject().apply {
            put("app", app)
            put("packageName", packageName)
            put("sender", sender)
            put("text", text)
            put("timestamp", System.currentTimeMillis())
        }
        val script = "if (typeof window !== 'undefined' && window.onJarvisNotification) { window.onJarvisNotification($payload); }"
        runOnUiThread {
            webView.evaluateJavascript(script, null)
        }
    }

    private fun requestAppPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        permissionLauncher.launch(permissions.toTypedArray())

        // Check overlay permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }
}

