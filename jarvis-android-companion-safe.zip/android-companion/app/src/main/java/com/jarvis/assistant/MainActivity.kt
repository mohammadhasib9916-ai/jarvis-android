package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Button
import android.widget.FrameLayout
import android.view.Gravity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
            fileUploadCallback?.onReceiveValue(uris)
        } else {
            fileUploadCallback?.onReceiveValue(null)
        }
        fileUploadCallback = null
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Handle runtime permission grants
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Permissions are not requested automatically. The user must enable them when needed.

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.setGeolocationEnabled(true)
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT

            addJavascriptInterface(JarvisJsBridge(this@MainActivity), "AndroidCompanion")

            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    // Deny by default. Location access must be explicitly approved by the user.
                    callback?.invoke(origin, false, false)
                }

                override fun onPermissionRequest(request: PermissionRequest?) {
                    // Never auto-grant microphone/camera to web content.
                    request?.deny()
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileUploadCallback?.onReceiveValue(null)
                    fileUploadCallback = filePathCallback

                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    filePickerLauncher.launch(intent)
                    return true
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString() ?: return false
                    if (url.startsWith("tel:") || url.startsWith("sms:") || url.startsWith("mailto:") || url.startsWith("geo:")) {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(intent)
                        return true
                    }
                    return false
                }
            }
        }

        // Native emergency stop button remains available above the web app.
        val root = FrameLayout(this)
        root.addView(webView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))
        val stopButton = Button(this).apply {
            text = "STOP JARVIS"
            contentDescription = "Emergency stop JARVIS"
            setOnClickListener {
                // Stop web audio/JavaScript activity and the floating overlay.
                webView.evaluateJavascript(
                    "(function(){try{window.speechSynthesis&&window.speechSynthesis.cancel();" +
                    "document.querySelectorAll('audio,video').forEach(function(x){x.pause();});" +
                    "if(window.stop)window.stop();}catch(e){}})();", null
                )
                webView.onPause()
                webView.pauseTimers()
                stopService(Intent(this@MainActivity, FloatingOverlayService::class.java))
                android.widget.Toast.makeText(
                    this@MainActivity,
                    "JARVIS paused. Reopen the app to resume.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }
        val stopParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END
        )
        root.addView(stopButton, stopParams)
        setContentView(root)

        // IMPORTANT: localhost is not a public server URL on a normal phone.
        // Replace this with the deployed HTTPS URL of your JARVIS web app before building.
        val appUrl = "https://REPLACE-WITH-YOUR-JARVIS-WEB-APP-URL"
        webView.loadUrl(appUrl)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
