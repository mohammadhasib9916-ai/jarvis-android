package com.jarvis.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * JARVIS Notification Listener Service
 * Intercepts incoming notifications to announce important alerts and support smart voice replies.
 * Enabled by user in Android Settings > Special App Access > Notification Access.
 */
class JarvisNotificationListener : NotificationListenerService() {

    // Simple deduplication cache to avoid re-announcing notifications within 30 seconds
    private val recentSignatures = LinkedHashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        val packageName = sbn.packageName ?: return
        // Ignore ongoing / non-clearable / system foreground notifications
        if (sbn.isOngoing) return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getString("android.title") ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""

        if (title.isBlank() && text.isBlank()) return

        // Privacy Filter: Filter out OTPs, verification codes, and passwords
        val lowerText = text.lowercase()
        if (lowerText.contains("otp") ||
            lowerText.contains("code") ||
            lowerText.contains("password") ||
            lowerText.contains("pin") ||
            lowerText.contains("کوڈ") ||
            lowerText.contains("رمز")
        ) {
            Log.d("JARVIS_NOTIF", "Privacy filter: Omitted sensitive security notification from $packageName")
            return
        }

        val appName = when {
            packageName.contains("whatsapp") -> "WhatsApp"
            packageName.contains("telegram") -> "Telegram"
            packageName.contains("messaging") || packageName.contains("mms") -> "SMS"
            else -> packageName.substringAfterLast('.')
        }

        val signature = "$packageName:$title:$text"
        val now = System.currentTimeMillis()
        synchronized(recentSignatures) {
            val lastSeen = recentSignatures[signature] ?: 0L
            if (now - lastSeen < 30_000L) {
                // Deduplicate within 30s
                return
            }
            recentSignatures[signature] = now
            if (recentSignatures.size > 100) {
                recentSignatures.entries.removeIf { now - it.value > 60_000L }
            }
        }

        Log.d("JARVIS_NOTIF", "Passing notification to JARVIS: $appName | $title")
        MainActivity.instance?.dispatchNotificationToWeb(appName, packageName, title, text)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
    }
}
