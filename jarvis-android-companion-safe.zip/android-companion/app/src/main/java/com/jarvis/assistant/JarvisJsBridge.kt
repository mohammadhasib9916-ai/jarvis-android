package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.widget.Toast

/**
 * JARVIS Native Android Bridge
 * Exposes native OS hardware and permission-protected capabilities to the JARVIS frontend.
 */
class JarvisJsBridge(private val context: Context) {

    @JavascriptInterface
    fun isNativeCompanion(): Boolean = true

    @JavascriptInterface
    fun getCompanionVersion(): String = "2.6.0-JARVIS-ANDROID"

    @JavascriptInterface
    fun getAppUrl(): String {
        return MainActivity.instance?.getEffectiveAppUrl() ?: MainActivity.DEFAULT_CLOUD_URL
    }

    @JavascriptInterface
    fun saveCustomAppUrl(url: String): Boolean {
        MainActivity.instance?.saveCustomAppUrl(url)
        return true
    }

    @JavascriptInterface
    fun makePhoneCall(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_CALL).apply {
            data = Uri.parse("tel:$phoneNumber")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phoneNumber")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(dialIntent)
        }
    }

    @JavascriptInterface
    fun openInstalledApp(packageName: String): Boolean {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            true
        } else {
            false
        }
    }

    @JavascriptInterface
    fun triggerVibration(milliseconds: Long) {
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(milliseconds)
        }
    }

    @JavascriptInterface
    fun getBatteryLevel(): Int {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        return bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
    }

    @JavascriptInterface
    fun adjustVolume(direction: String): Boolean {
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
            if (audioManager != null) {
                val adjustDirection = when (direction.lowercase()) {
                    "down", "lower", "کم", "decrease" -> android.media.AudioManager.ADJUST_LOWER
                    "up", "raise", "زیادہ", "increase" -> android.media.AudioManager.ADJUST_RAISE
                    "mute", "silent", "خاموش" -> android.media.AudioManager.ADJUST_MUTE
                    else -> android.media.AudioManager.ADJUST_LOWER
                }
                audioManager.adjustStreamVolume(
                    android.media.AudioManager.STREAM_MUSIC,
                    adjustDirection,
                    android.media.AudioManager.FLAG_SHOW_UI
                )
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun emergencyStopAll(): Boolean {
        return try {
            // Stop floating overlay service if active
            context.stopService(Intent(context, FloatingOverlayService::class.java))
            true
        } catch (e: Exception) {
            false
        }
    }

    // Accessibility Navigation Actions
    @JavascriptInterface
    fun navigateBack(): Boolean = JarvisAccessibilityService.instance?.performBack() ?: false

    @JavascriptInterface
    fun navigateHome(): Boolean = JarvisAccessibilityService.instance?.performHome() ?: false

    @JavascriptInterface
    fun openNotificationsShade(): Boolean = JarvisAccessibilityService.instance?.performNotifications() ?: false

    @JavascriptInterface
    fun getScreenContext(): String = JarvisAccessibilityService.instance?.getScreenSummary() ?: "No accessibility context"

    @JavascriptInterface
    fun openDeviceSettings(settingType: String): Boolean {
        return try {
            val action = when (settingType.lowercase()) {
                "sound", "volume", "آواز" -> Settings.ACTION_SOUND_SETTINGS
                "wifi", "وائی فائی" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth", "بلوٹوتھ" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "notification", "نوٹیفکیشن" -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
                "overlay", "فلوٹنگ" -> Settings.ACTION_MANAGE_OVERLAY_PERMISSION
                "accessibility", "ایکسیسیبلٹی" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            val intent = Intent(action).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun searchMessages(query: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                type = "vnd.android-dir/mms-sms"
                putExtra("sms_body", query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun shareText(text: String, title: String): Boolean {
        return try {
            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, text)
                type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, title).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(shareIntent)
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun hasNotificationAccess(): Boolean {
        return try {
            val enabledListeners = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            )
            val myPackage = context.packageName
            enabledListeners != null && enabledListeners.contains(myPackage)
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun hasAccessibilityAccess(): Boolean {
        return JarvisAccessibilityService.instance != null
    }

    @JavascriptInterface
    fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    @JavascriptInterface
    fun startFloatingAssistantOverlay() {
        val intent = Intent(context, FloatingOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        Toast.makeText(context, "JARVIS Floating Assistant Enabled", Toast.LENGTH_SHORT).show()
    }
}
