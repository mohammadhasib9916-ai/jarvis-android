package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log

/**
 * JARVIS Accessibility Service
 * Grants JARVIS screen context awareness and UI automation for cross-app actions.
 * Activated by user in Android Settings > Accessibility > JARVIS Assistant.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return
        currentForegroundApp = packageName
    }

    override fun onInterrupt() {
        Log.w("JARVIS_ACC", "Accessibility service interrupted")
    }

    fun performBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun getScreenSummary(): String {
        val root = rootInActiveWindow ?: return "Active App: $currentForegroundApp"
        val builder = StringBuilder("App: $currentForegroundApp\n")
        extractTextNodes(root, builder, 0)
        return builder.toString().take(1000)
    }

    private fun extractTextNodes(node: AccessibilityNodeInfo?, builder: StringBuilder, depth: Int) {
        if (node == null || depth > 5) return
        // NEVER read password fields for privacy & security
        if (node.isPassword) return

        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrEmpty()) {
            builder.append("- ").append(text).append("\n")
        } else if (!desc.isNullOrEmpty()) {
            builder.append("- ").append(desc).append("\n")
        }

        for (i in 0 until node.childCount) {
            extractTextNodes(node.getChild(i), builder, depth + 1)
        }
    }

    companion object {
        var instance: JarvisAccessibilityService? = null
            private set
        var currentForegroundApp: String = ""
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d("JARVIS_ACC", "JARVIS Accessibility Service Connected")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }
}
