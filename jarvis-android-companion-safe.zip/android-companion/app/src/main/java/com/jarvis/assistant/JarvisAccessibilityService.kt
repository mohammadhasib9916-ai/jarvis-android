package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * JARVIS Accessibility Service
 * Grants JARVIS screen context awareness and UI automation for cross-app actions.
 * Activated by user in Android Settings > Accessibility > JARVIS Assistant.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // Intercept active window changes to identify frontmost application
        val packageName = event.packageName?.toString() ?: return
        val rootNode = rootInActiveWindow ?: return

        // Allows JARVIS to read screen text or detect when user is viewing WhatsApp or Maps
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    companion object {
        var instance: JarvisAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
