# JARVIS (جارویس) — Native Android Companion Architecture

This directory contains the production-grade **Native Android Companion Architecture** for JARVIS (جارویس).

## Architecture Overview

While the JARVIS web application and PWA handle conversational voice interactions, real-time Google Maps Routes & Places APIs, and device URL intents (`tel:`, `sms:`, `mailto:`, `geo:`), native Android security limits certain capabilities inside standard browsers (such as drawing a floating bubble over third-party apps, inspecting incoming WhatsApp notifications, and automated button clicks).

The companion bridge bridges this gap seamlessly:

1. **`MainActivity.kt`**: Runs an accelerated Android WebView with full hardware acceleration, automated microphone permission injection, camera/file picker integration via `WebChromeClient`, and the `@JavascriptInterface` bridge (`AndroidCompanion`).
2. **`JarvisJsBridge.kt`**: Exposes native OS calls directly to the JARVIS frontend:
   - Direct phone calling (`makePhoneCall`)
   - Cross-app launch (`openInstalledApp`)
   - Haptic vibration feedback (`triggerVibration`)
   - Battery level readout (`getBatteryLevel`)
   - Floating assistant bubble activation (`startFloatingAssistantOverlay`)
3. **`FloatingOverlayService.kt`**: Uses Android's `SYSTEM_ALERT_WINDOW` permission to display an Arc Reactor floating head over any active app (e.g. YouTube, Maps, WhatsApp), letting you summon JARVIS without leaving your current task.
4. **`JarvisNotificationListener.kt`**: Extends `NotificationListenerService` to monitor incoming notifications from messaging apps and support hands-free voice replies.
5. **`JarvisAccessibilityService.kt`**: Extends `AccessibilityService` for user-approved screen reading and UI automation in accordance with Android accessibility guidelines.

## Setup & Compilation Steps

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34 (Android 14)
- JDK 17

### Building the APK
1. Open the `android-companion` directory in Android Studio (or compile automatically using GitHub Actions).
2. In `MainActivity.kt`, `DEFAULT_CLOUD_URL` points to your published JARVIS Cloud Run URL:
   `https://ais-pre-ycq4dyrjjh2yp6rxr6jzgp-125679939886.asia-northeast1.run.app`
   **CRITICAL NOTICE:** Never use `http://localhost:3000` for a physical phone APK. A physical Android phone cannot connect to localhost because `localhost` refers to the phone itself.
3. Build and install:
   ```bash
   ./gradlew assembleDebug
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

### Enabling Special Permissions in Android Settings
- **Floating Overlay**: Go to **Settings > Apps > Special App Access > Display over other apps > JARVIS (جارویس)** and toggle **Allow**.
- **Notification Listener**: Go to **Settings > Apps > Special App Access > Notification Access > JARVIS (جارویس)** and toggle **Allow**.
- **Screen Reading (Optional)**: Go to **Settings > Accessibility > JARVIS Screen Automation** and toggle **On**.
